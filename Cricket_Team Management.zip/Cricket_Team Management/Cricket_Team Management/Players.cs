﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Players : Form
    {
        public Players()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            Add_Player play = new Add_Player();
            play.Show();
            this.Hide();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            Delete_Player delete = new Delete_Player();
            delete.Show();
            this.Hide();
        }

        private void btndisplay_Click(object sender, EventArgs e)
        {
            Display_Players display = new Display_Players();
            display.Show();
            this.Hide();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            Update_Player update = new Update_Player();
            update.Show();
            this.Hide();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            Search_Player search = new Search_Player();
            search.Show();
            this.Hide();
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Dashboard ob = new Dashboard();
            ob.Show();
            base.OnFormClosed(e);
        }

        private void Players_Load(object sender, EventArgs e)
        {

        }
    }
}

