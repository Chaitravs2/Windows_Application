﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Management
{
    public partial class Add_Team : Form
    {
        SqlConnection conn;
        public Add_Team()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Teams ob = new Teams();
            ob.Show();
            base.OnFormClosed(e);
        }

        private void lblid_Click(object sender, EventArgs e)
        {

        }

        private void Add_Team_Load(object sender, EventArgs e)
        {
            string query = "select * from countries ";
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                cmbcid.DataSource = ds.Tables[0];
                cmbcid.ValueMember = ds.Tables[0].Columns[0].ToString();
                cmbcid.DisplayMember = ds.Tables[0].Columns[0].ToString();
                conn.Close();

            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string query = string.Format("insert into teams values({0},'{1}',{2})", txttid.Value, txttname.Text, cmbcid.Text);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Team details added successfully");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }
    }
}
