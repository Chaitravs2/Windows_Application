﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Countries : Form
    {
        public Countries()
        {
            InitializeComponent();
        }

        
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Dashboard ob = new Dashboard();
            ob.Show();
            base.OnFormClosed(e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Add_Country ob = new Add_Country();
            ob.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Delete_Country ob = new Delete_Country();
            ob.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Display_Country ob = new Display_Country();
            ob.Show();
            this.Hide();
        }
    }
}
