﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Management
{
    public partial class Update_Team : Form
    {
        SqlConnection conn;
        public Update_Team()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Teams ob = new Teams();
            ob.Show();
            base.OnFormClosed(e);
        }

        private void txttname_TextChanged(object sender, EventArgs e)
        {

        }

        private void Update_Team_Load(object sender, EventArgs e)
        {
            panel.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel.Visible = false;
            string id = txttid.Value.ToString();
            try
            {
                conn.Open();
                string query = "select * from Teams where Team_id=" + id;
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {

                    Team_Details t = new Team_Details();
                    t.teamid = int.Parse(reader[0].ToString());
                    t.team_name = reader[1].ToString();
                    t.countryid = int.Parse(reader[2].ToString());
                    updateme(t);
                    panel.Visible = true;
                }
                else
                    MessageBox.Show(" sorry team id does not exist");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);

            }
        }

        private void updateme(Team_Details t)
        {
            txttname.Text = t.team_name;
            txtcid.Value = t.countryid;
            panel.Visible = true;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            string query = string.Format("update teams set team_name='{0}',country_id={1} where team_id = {2}", txttname.Text, txtcid.Value, txttid.Value);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated");
                conn.Close();

            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }
    }
}
