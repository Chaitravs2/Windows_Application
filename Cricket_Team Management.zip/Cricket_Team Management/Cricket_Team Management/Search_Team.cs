﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Management
{
    public partial class Search_Team : Form
    {
        SqlConnection conn;
        public Search_Team()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Teams ob = new Teams();
            ob.Show();
            base.OnFormClosed(e);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Search_Team_Load(object sender, EventArgs e)
        {
            panel.Visible = false;
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            panel.Visible = false;
            string id = txttid.Value.ToString();
            try
            {
                conn.Open();
                string sql = "select * from Teams where Team_id=" + id;
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    Team_Details t = new Team_Details();
                    t.teamid = int.Parse(reader[0].ToString());
                    t.team_name = reader[1].ToString();
                    t.countryid = int.Parse(reader[2].ToString());
                    lblid.Text = reader[0].ToString();
                    lbltname.Text = reader[1].ToString();
                    lblcid.Text = reader[2].ToString();
                    panel.Visible = true;
                }
                else
                    MessageBox.Show("Team id doesnot exist");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }
    }
}
